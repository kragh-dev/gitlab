﻿using System;

namespace Com.Cognizant.Truyum.Dao
{
    class CartEmptyException : Exception
    {
        string output;
        public CartEmptyException() : base("Cart is Empty")
        {

        }
        public CartEmptyException(string message) : base(message)
        {
            output = message;
        }
    }
}
