﻿using System.Web.UI;

namespace truYumOnline.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}