﻿using System.Collections.Generic;
using System.Linq;

namespace Com.Cognizant.Truyum.Model
{
    public class Cart
    {
        private List<MenuItem> menuItemList = new List<MenuItem>();
        private double total;
        public List<MenuItem> MenuItemList
        {
            get {
                return menuItemList;
            }
            set {
                menuItemList = value;
            }
        }
        public double Total
        {
            get {
                return total;
            }
            set {
                total = menuItemList.Count();
            }
        }
        public Cart()
        {

        }
        public Cart(List<MenuItem> MenuListItem, double Total)
        {
            this.MenuItemList = MenuListItem;
            this.Total = this.Total + Total;
        }
    }
}
