﻿using Com.Cognizant.Truyum.Model;
using System;
using System.Collections.Generic;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoCollectionTest
    {
        static string format = "{0,-10}{1,-20}{2,-15}{3,-10}{4,-15}{5,-15}{6}";
        static string list = string.Format(format, "ID","Name","Price","Active","Date of Launch","Category","Free Delivery");
        public MenuItemDaoCollectionTest()
        {
            MenuItemDaoCollection menuItemDao = new MenuItemDaoCollection();
            string ch;
            Console.WriteLine();
            l1: Console.Write("1. Get Menu Item List - Admin\n2. Get Menu Item List - Customer\n3. Modify Menu Item - Admin\n4. Get Menu Item - Admin\n\nEnter your choice: ");
            ch = Console.ReadLine();
            switch (ch)
            {
                case "1":
                    {
                        TestGetMenuItemListAdmin(menuItemDao);
                        goto l1;
                    }
                case "2":
                    {
                        TestGetMenuItemListCustomer(menuItemDao);
                        goto l1;
                    }
                case "3":
                    {
                        TestModifyMenuItem(menuItemDao);
                        goto l1;
                    }
                case "4":
                    {
                        TestGetMenuItem(menuItemDao);
                        goto l1;
                    }
                default:
                    {
                        Console.WriteLine("Exiting...");
                        break;
                    }
            }
            Console.WriteLine();
            Console.WriteLine("{0,-20}{1,20}", "hello", "world");

        }
        public static void TestGetMenuItemListAdmin(MenuItemDaoCollection menuItemDao)
        {
            List<MenuItem> menuItemList = menuItemDao.GetMenuItemListAdmin();
            Console.WriteLine("\n"+list);
            foreach (MenuItem item in menuItemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
        public static void TestGetMenuItemListCustomer(MenuItemDaoCollection menuItemDao)
        {
            List<MenuItem> menuItemList = menuItemDao.GetMenuItemListCustomer();
            Console.WriteLine("\n"+list);
            foreach (MenuItem item in menuItemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
        public static void TestModifyMenuItem(MenuItemDaoCollection menuItemDao)
        {
            List<MenuItem> menuItemList = menuItemDao.GetMenuItemListAdmin();
            Console.WriteLine("\nMenu before modification:\n");
            Console.WriteLine(list);
            foreach (MenuItem item in menuItemList)
            {
                Console.WriteLine(item);
            }
            Console.Write("\nEnter the item ID you wish to modify: ");
            long id = long.Parse(Console.ReadLine());
            Console.Write("Enter Menu Item Name: ");
            string itemName = Console.ReadLine();
            Console.Write("Enter Menu Item Price: ");
            float itemPrice = float.Parse(Console.ReadLine());
            Console.Write("Active (Yes/No)");
            bool itemStatus = (Console.ReadLine().Equals("yes", StringComparison.InvariantCultureIgnoreCase)) == true ? true : false;
            Console.Write("Enter Date of Launch: ");
            DateTime dateOfLaunch = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            Console.Write("Enter Menu Item Category: ");
            string category = Console.ReadLine();
            Console.Write("Free Delivery (Yes/No)");
            bool deliveryStatus = (Console.ReadLine().Equals("yes", StringComparison.InvariantCultureIgnoreCase)) == true ? true : false;
            menuItemDao.ModifyMenuItem(new MenuItem(id,itemName,itemPrice,itemStatus,dateOfLaunch,category,deliveryStatus));
            Console.WriteLine("\nMenu after modification:\n");
            menuItemList = menuItemDao.GetMenuItemListAdmin();
            Console.WriteLine(list);
            foreach (MenuItem item in menuItemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
        public static void TestGetMenuItem(MenuItemDaoCollection menuItemDao)
        {
            Console.Write("\nEnter Menu Item ID: ");
            long itemId = long.Parse(Console.ReadLine());
            Console.WriteLine("\n"+list);
            Console.WriteLine(menuItemDao.GetMenuItem(itemId)+"\n");
        }
    }
}
