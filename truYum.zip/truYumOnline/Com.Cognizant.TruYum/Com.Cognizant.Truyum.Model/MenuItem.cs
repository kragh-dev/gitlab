﻿using System;

namespace Com.Cognizant.Truyum.Model
{
    public class MenuItem
    {
        private long id;
        private string name;
        private float price;
        private Boolean active;
        private DateTime dateOfLaunch;
        private string category;
        private Boolean freeDelivery;
        public long ID
        {
            get {
                return id;
            }
            set {
                id = value;
            }
        }
        public string Name
        {
            get {
                return name;
            }
            set {
                name = value;
            }
        }
        public float Price
        {
            get {
                return price;
            }
            set {
                price = value;
            }
        }
        public Boolean Active {
            get {
                return active;
            }
            set {
                active = value;
            }
        }
        public DateTime DateOfLaunch
        {
            get {
                return dateOfLaunch;
            }
            set {
                dateOfLaunch = value;
            }
        }
        public string Category
        {
            get {
                return category;
            }
            set {
                category = value;
            }
        }
        public Boolean FreeDelivery
        {
            get {
                return freeDelivery;
            }
            set {
                freeDelivery = value;
            }
        }
        public MenuItem()
        {

        }
        public MenuItem(long ID, string Name, float Price, Boolean Active, DateTime DateOfLaunch, string Category, Boolean FreeDelivery)
        {
            this.ID = ID;
            this.Name = Name;
            this.Price = Price;
            this.Active = Active;
            this.DateOfLaunch = DateOfLaunch;
            this.Category = Category;
            this.FreeDelivery = FreeDelivery;
        }
        public override string ToString()
        {
            string _active = (Active) ? "Yes" : "No";
            string _freeDelivery = (FreeDelivery) ? "Yes" : "No";
            string item = string.Format("{0,-10}{1,-20}{2,-15}{3,-10}{4,-15}{5,-15}{6}",ID,Name,Price.ToString("0.00"),_active,DateOfLaunch.ToShortDateString(),Category,_freeDelivery);
            return item;
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
    }
}
