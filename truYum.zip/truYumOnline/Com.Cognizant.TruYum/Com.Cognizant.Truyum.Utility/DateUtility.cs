﻿using System;

namespace Com.Cognizant.Truyum.Utility
{
    public class DateUtility
    {
        public DateTime ConvertToDate(string inputDate)
        {
            return DateTime.Parse(inputDate);
        }
    }
}
