﻿using Com.Cognizant.Truyum.Model;
using System.Collections.Generic;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoCollection : ICartDao
    {
        private static Dictionary<long, Cart> userCarts;
        public CartDaoCollection()
        {
            if (userCarts == null)
                userCarts = new Dictionary<long, Cart>();
        }
        //This method is used to add an item to user cart
        public void AddCartItem(long userId, long menuItemId)
        {
            MenuItemDaoCollection menuItemDao = new MenuItemDaoCollection();
            MenuItem menuItem = menuItemDao.GetMenuItem(menuItemId);
            if (userCarts.ContainsKey(userId))
            {
                userCarts[userId].MenuItemList.Add(menuItem);
                userCarts[userId].Total += menuItem.Price;
            }
            else
            {
                userCarts.Add(userId, new Cart(new List<MenuItem>() {menuItem},menuItem.Price));
            }
        }

        //This method is used to retrieve all the items from the cart of a particular user
        public Cart GetAllCartItems(long userId)
        {
            if (userCarts.ContainsKey(userId))
            {
                return userCarts[userId];
            }
            else
                throw new CartEmptyException("Cart is empty");
        }

        //This method is used to remove a particular item from cart for a particular user
        public void RemoveCartItem(long userId, long menuItemId)
        {
            Cart cartItems = GetAllCartItems(userId);
            int itemId = cartItems.MenuItemList.FindIndex(item => item.ID == menuItemId);
            userCarts[userId].MenuItemList.Remove(cartItems.MenuItemList[itemId]);
        }
    }
}