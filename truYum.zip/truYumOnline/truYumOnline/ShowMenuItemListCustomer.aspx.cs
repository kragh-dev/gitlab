﻿using Com.Cognizant.Truyum.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace truYumOnline
{
    public partial class ShowMenuItemListCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IMenuItemDao menuItemDao = new MenuItemDaoCollection();
            menuTable.DataSource = menuItemDao.GetMenuItemListCustomer();
            menuTable.DataBind();
        }
        [WebMethod, ScriptMethod]
        public static bool AddItemToCart(long itemId, long userId)
        {
            ICartDao cartDao;
            if (HttpContext.Current.Session["customerObj"] == null)
            {
                cartDao = new CartDaoCollection();
                HttpContext.Current.Session["customerObj"] = cartDao;
            }
            else
            {
                cartDao = (ICartDao)HttpContext.Current.Session["customerObj"];
            }
            cartDao.AddCartItem(userId, itemId);
            return true;
        }
    }
}