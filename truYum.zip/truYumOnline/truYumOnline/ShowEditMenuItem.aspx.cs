﻿using Com.Cognizant.Truyum.Dao;
using truYumMenuItem = Com.Cognizant.Truyum.Model.MenuItem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace truYumOnline
{
    public partial class ShowEditMenuItem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IMenuItemDao menuItemDao;
                if (HttpContext.Current.Session["adminObj"] == null)
                {
                    menuItemDao = new MenuItemDaoCollection();
                    HttpContext.Current.Session["adminObj"] = menuItemDao;
                }
                else
                {
                    menuItemDao = (IMenuItemDao)HttpContext.Current.Session["adminObj"];
                    HttpContext.Current.Session["adminObj"] = menuItemDao;
                }
                truYumMenuItem item = menuItemDao.GetMenuItem(long.Parse(Request.QueryString["menuItemId"]));
                txtItemName.Text = item.Name;
                txtPrice.Text = item.Price.ToString();
                if (item.Active.Equals(true))
                {
                    radioItemActive.SelectedValue = "Yes";
                }
                else
                {
                    radioItemActive.SelectedValue = "No";
                }
                txtDOL.Text = item.DateOfLaunch.ToString("yyyy-MM-dd");
                dropDownItemCategory.SelectedValue = item.Category;
                checkBoxFreeDelivery.Checked = item.FreeDelivery;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            IMenuItemDao menuItemDao;
            if (HttpContext.Current.Session["adminObj"] == null)
            {
                menuItemDao = new MenuItemDaoCollection();
                HttpContext.Current.Session["adminObj"] = menuItemDao;
            }
            else
            {
                menuItemDao = (IMenuItemDao)HttpContext.Current.Session["adminObj"];
                HttpContext.Current.Session["adminObj"] = menuItemDao;
            }
            long id = long.Parse(Request.QueryString["menuItemId"]);
            string itemName = txtItemName.Text;
            float itemPrice = float.Parse(txtPrice.Text);
            bool itemStatus = (radioItemActive.SelectedValue.Equals("yes", StringComparison.InvariantCultureIgnoreCase)) == true ? true : false;
            DateTime dateOfLaunch = DateTime.ParseExact(txtDOL.Text, "yyyy-MM-dd", null);
            string category = dropDownItemCategory.SelectedValue;
            bool deliveryStatus = checkBoxFreeDelivery.Checked == true ? true : false;
            truYumMenuItem item = new truYumMenuItem(id, itemName, itemPrice, itemStatus, dateOfLaunch, category, deliveryStatus);
            menuItemDao.ModifyMenuItem(item);
            Response.Redirect("EditMenuItemStatus.aspx");
        }
    }
}