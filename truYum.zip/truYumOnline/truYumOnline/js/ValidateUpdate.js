﻿function validateMenuItemForm()
{
    var regex = "/^[0-9]+$/";
    var itemName = document.getElementById('ContentPlaceHolder1_txtItemName').value;
    var itemPrice = document.getElementById('ContentPlaceHolder1_txtPrice').value;
    if (itemName == "")
    {
        alert("Please Enter Name");
        return false;
    }
    if (itemPrice == "")
    {
        alert("Please Enter Price");
        return false;
    }
    if (!Number(itemPrice))
    {
        alert("Price should have only numeric values");
        return false;
    }
}