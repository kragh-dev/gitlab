﻿function DeleteFromCart(itemId, userId) {
    PageMethods.DeleteItemFromCart(itemId, userId, onSuccess, onFailure);
}
function onSuccess(result) {
    document.getElementById('cartStatus').innerHTML = "Item added to cart successfully";
    setTimeout(function () { document.getElementById("cartStatus").innerHTML = "" }, 2500);
    window.location = "ShowCart.aspx";
}

function onFailure(error) {
    alert(error);
}