﻿function AddToCart(itemId, userId) {
    PageMethods.AddItemToCart(itemId, userId, onSuccess, onFailure);
}
function onSuccess(result) {
    document.getElementById('cartAddStatus').innerHTML = "Item added to cart successfully";
    setTimeout(function () { document.getElementById("cartAddStatus").innerHTML = "" }, 2500);
    return false;
}

function onFailure(error) {
    alert(error);
}