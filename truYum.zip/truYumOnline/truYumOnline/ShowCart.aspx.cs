﻿using Com.Cognizant.Truyum.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace truYumOnline
{
    public partial class ShowCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ICartDao cartItemDao;
            if (HttpContext.Current.Session["customerObj"] == null)
            {
                cartItemDao = new CartDaoCollection();
                HttpContext.Current.Session["customerObj"] = cartItemDao;
            }
            else
            {
                cartItemDao = (ICartDao)HttpContext.Current.Session["customerObj"];
            }
            long id = 1;
            try
            {
                var count = cartItemDao.GetAllCartItems(id).MenuItemList.Count;
                if (count > 0)
                {
                    cartTable.DataSource = cartItemDao.GetAllCartItems(id).MenuItemList;
                    cartTable.DataBind();
                    lblTotal.Visible = true;
                    cartTotal.Text = "&#8377; " + cartItemDao.GetAllCartItems(id).MenuItemList.Sum(item => item.Price).ToString();
                }
                else
                {
                    throw new CartEmptyException();
                }
            }
            catch (CartEmptyException cartEmptyException)
            {
                cartEmpty.Text = cartEmptyException.Message+". Use 'Add to Cart' option in the ";
                cartEmptyLink.Visible = true;
            }
        }

        [WebMethod, ScriptMethod]
        public static bool DeleteItemFromCart(long itemId, long userId)
        {
            ICartDao cartDao;
            if (HttpContext.Current.Session["customerObj"] == null)
            {
                cartDao = new CartDaoCollection();
                HttpContext.Current.Session["customerObj"] = cartDao;
            }
            else
            {
                cartDao = (ICartDao)HttpContext.Current.Session["customerObj"];
            }
            cartDao.RemoveCartItem(userId, itemId);
            return true;
        }
    }
}