﻿using System;
using System.Collections.Generic;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    class MenuItemDaoCollection : IMenuItemDao
    {
        public List<MenuItem> menuItemList;
        public MenuItemDaoCollection() {
            if (menuItemList == null)
            {
                menuItemList = new List<MenuItem>()
                {
                    new MenuItem(101,"Sandwich",99.50f,true,DateTime.ParseExact("15/03/2017","dd/MM/yyyy",null),"Main Course",true),
                    new MenuItem(102,"Burger",129f,true,DateTime.ParseExact("23/12/2017","dd/MM/yyyy",null),"Main Course",false),
                    new MenuItem(103,"Pizza",149f,true,DateTime.ParseExact("21/08/2018","dd/MM/yyyy",null),"Main Course",false),
                    new MenuItem(104,"French Fries",57f,false,DateTime.ParseExact("02/07/2017","dd/MM/yyyy",null),"Starters",true),
                    new MenuItem(105,"Chocolate Brownie",32f,true,DateTime.ParseExact("02/11/2022","dd/MM/yyyy",null),"Dessert",true),
                };
            }
        }
        public List<MenuItem> GetMenuItemListAdmin()
        {
            return menuItemList;
        }
        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> customerItemList = new List<MenuItem>();
            foreach (MenuItem item in menuItemList)
            {
                if (item.Active && DateTime.Compare(item.DateOfLaunch, DateTime.Now) > 0)
                {
                    customerItemList.Add(item);
                }
            }
            return customerItemList;
        }
        public MenuItem GetMenuItem(long menuItemId)
        {
            int itemIndex = menuItemList.FindIndex(item => item.ID == menuItemId);
            return menuItemList[itemIndex];
        }
        public void ModifyMenuItem(MenuItem menuItem)
        {
            int itemIndex = menuItemList.FindIndex(item => item.ID == menuItem.ID);
            menuItemList[itemIndex] = menuItem;
        }
    }
}