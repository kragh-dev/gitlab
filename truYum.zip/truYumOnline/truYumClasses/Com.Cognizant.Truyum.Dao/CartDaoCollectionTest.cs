﻿using System;
using System.Collections.Generic;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    class CartDaoCollectionTest
    {
        static string format = "{0,-10}{1,-20}{2,-15}{3,-10}{4,-15}{5,-15}{6}";
        static string list = string.Format(format, "ID", "Name", "Price", "Active", "Date of Launch", "Category", "Free Delivery");
        public CartDaoCollectionTest()
        {
            MenuItemDaoCollection menuItemDao = new MenuItemDaoCollection();
            List<MenuItem> menuItemList = menuItemDao.GetMenuItemListAdmin();
            Console.WriteLine("Available Items:\n" + list);
            foreach (MenuItem item in menuItemList)
            {
                Console.WriteLine(item);
            }
            string ch;
            CartDaoCollection cartDao = new CartDaoCollection();
            Console.WriteLine();
            l1: Console.Write("1. Add Cart Item\n2. Remove Cart Item\n3. Get All Cart Items\n\nEnter your choice: ");
            ch = Console.ReadLine();
            switch (ch)
            {
                case "1":
                    {
                        TestAddCartItem(cartDao);
                        goto l1;
                    }
                case "2":
                    {
                        TestRemoveCartItem(cartDao);
                        goto l1;
                    }
                case "3":
                    {
                        TestGetAllCartItems(cartDao);
                        goto l1;
                    }
                default: {
                        Console.WriteLine("Exiting...");
                        break;
                    }
                
            }
            Console.WriteLine();
        }
        public static void TestAddCartItem(CartDaoCollection cartDao)
        {
            Console.Write("Enter User ID: ");
            long userId = long.Parse(Console.ReadLine());
            Console.Write("Enter Item ID to add to user cart: ");
            long itemId = long.Parse(Console.ReadLine());
            cartDao.AddCartItem(userId,itemId);
            Cart cartItems = cartDao.GetAllCartItems(1);
            Console.WriteLine("\nAfter adding entered item in cart...\n\n"+list);
            foreach (MenuItem item in cartItems.MenuItemList)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
        public static void TestRemoveCartItem(CartDaoCollection cartDao)
        {
            try {
                Console.Write("Enter User ID: ");
                long userId = long.Parse(Console.ReadLine());
                Cart cartItems = cartDao.GetAllCartItems(userId);
                Console.WriteLine("\n" + list);
                foreach (MenuItem item in cartItems.MenuItemList)
                {
                    Console.WriteLine(item);
                }
                Console.Write("Enter Item ID to remove from user cart: ");
                long itemId = long.Parse(Console.ReadLine());
                cartDao.RemoveCartItem(userId, itemId);
                cartItems = cartDao.GetAllCartItems(userId);
                foreach (MenuItem item in cartItems.MenuItemList)
                {
                    Console.WriteLine(item);
                }
                Console.WriteLine();
                throw new CartEmptyException();
            }
            catch (CartEmptyException e)
            {
                Console.WriteLine("\n"+e.Message+"\n");
            }
        }
        public static void TestGetAllCartItems(CartDaoCollection cartDao)
        {
            try {
                Console.Write("Enter User ID: ");
                long userId = long.Parse(Console.ReadLine());
                Cart cartItems = cartDao.GetAllCartItems(userId);
                Console.WriteLine("\n" + list);
                foreach (MenuItem item in cartItems.MenuItemList)
                {
                    Console.WriteLine(item);
                }
                Console.WriteLine();
                throw new CartEmptyException();
            }
            catch (CartEmptyException e)
            {
                Console.WriteLine("\n"+e.Message+"\n");
            }
        }
    }
}
